<?php
    require_once("./system_proc.php");
  // Check if the form is submitted
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $image = $_FILES['receipt_image'];
    $imageName = $image['name'];
    $imageTmpPath = $image['tmp_name'];
    
    // Validate form data (you can add more validation as per your requirements)
    if (empty($product_name) || empty($price) || empty($image)) {
      echo "<p>Please fill in all required fields or no image selected.</p>";
    } else {

        // Define the directory to store the uploaded images
        $uploadDirectory = 'uploads/';

        // Generate a unique filename for the uploaded image
        $uploadedImagePath = $uploadDirectory . uniqid('prod_') . '_' . $imageName;

        // Move the uploaded image to the destination directory
        move_uploaded_file($imageTmpPath, $uploadedImagePath);
      
        // Prepare and execute the SQL query
        $sql = "INSERT INTO tblproduct (prod_name, prod_price, prod_description, prod_img_path) VALUES ('$product_name', '$price', '$description', '$uploadedImagePath')";

        $stmt = $pdo->prepare($sql);        

        // Assume $stmt is your prepared statement object
        if ($stmt->execute()) {
            // Execution was successful
            echo "<p>Product registered successfully.</p>";
            header("Location: index.php");        
            echo "Image uploaded successfully!";
            exit;
        } else {
            // Execution failed
            echo "Error executing statement: " . $stmt->errorInfo()[2];
        }     

      // Close the database connection
      mysqli_close($conn);
    }
  }
  ?>