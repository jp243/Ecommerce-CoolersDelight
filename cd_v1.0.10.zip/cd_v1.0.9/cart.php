<div class="tab-pane fade" id="shop-cart" role="tabpanel" aria-labelledby="ex1-tab-4">
 
    <div class="container-fluid px-5 py-3" >

        <div class="d-flex align-items-center justify-content-between">
        <h3 class="text-light me-3"><i class="fa fa-shopping-cart"></i> My Cart</h3>
        <button type="button" class="btn btn-light" data-toggle="modal">Order Now</button>
        </div>

        <div class="row">

        <?php 
                                      $prod_que = getAllCartByUser($_SESSION['user_id']);
                                      if ($prod_que->num_rows > 0) {
                                          
                                          while ($products = $prod_que->fetch_array()) {
                                            ?>

                                          <!-- PRODUCT -->
                                            <div class="col-lg-4 col-sm-2 p-3">

                                              <div class="card p-3">

                                              <form action="" method="post">

                                              <div style="height: 17rem;  background: url(./assets/img/<?php echo $products['prod_img'] ?>); background-repeat: no-repeat; background-position: center;"></div>

                                                  <h4 class="text-capitalize"><?php echo $products['prod_name'] ?></h4>
                                                  
												  <div class="d-flex align-items-center">
                                                      <span class="me-3">Price:</span>
                                                  		<div class="d-flex">
														  <span class="h2">₱ <?php echo number_format($products['prod_sprice'],2) ?> - <?php echo number_format($products['total'],2) ?> </span>
                                                  		</div>
                                                  </div>
												  
												<?php 
                                                    if (isset($_SESSION['user_id'])) {
                                                        ?>
                                                              <div class="d-flex align-items-center">
                                                      <span class="me-3">Quantity:</span>

                                                      <div class="d-flex">
                                                          <button type="button" class="btn sub" id="subtract"> <i class="fa fa-minus" ></i></button>
                                                          <input type="text" name="quantity" id="quantity" value="<?php echo $products['quantity'] ?>" class="form-control text-center" style="width: 5rem;">
                                                          <button type="button" class="btn add" id="add"> <i class="fa fa-plus" ></i></button>
                                                      </div>
                                                      
                                                  </div>

                                                        <?php
                                                    }
                                                ?>
                                                  

                                                  <style>
                                                    @media (max-width: 305px) {
                                                      #subtract i{
                                                        width: 10px !important;
                                                        
                                                      }
                                                      #subtract, #add{
                                                        width: 10px !important;
                                                      }
                                                      #add i{
                                                        width: 10px !important;
                                                      }
                                                      #quantity{
                                                        width: 50px !important;
                                                      }
                                                    }

                                                    @media (max-width: 263px){
                                                      #subtract i{
                                                        width: 10px !important;
                                                        
                                                      }
                                                      #subtract, #add{
                                                        width: 5px !important;
                                                        font-size: 10px;
                                                        padding: 10px 15px; 
                                                      }
                                                      #add i{
                                                        width: 10px !important;
                                                        font-size: 10px;
                                                      
                                                      }
                                                      #quantity{
                                                        font-size: 10px;
                                                        width: 30px !important;
                                                        
                                                      }
                                                    }
                                                  </style>
                                                
                                                  <input type="hidden" name="user_id" value="<?php echo @$_SESSION['user_id'] ?>">
                                                  <input type="hidden" name="prod_id" value="<?php echo $products['prod_id'] ?>">
                                                  <input type="hidden" name="prod_price" value="<?php echo $products['prod_sprice'] ?>">
                                                  <div class="d-flex mt-4">
                                                     
                                                
                                                  <button type="submit" class="btn w-100 me-1 text-light" style=" background: var(--default) !important;"><i class="fa fa-plus"></i> Update</button>
                                                  <a href="?remove&prod_id=<?php echo $products['prod_id'] ?>" class="btn w-100 ms-1 text-light" style=" background: var(--default) !important;"><i class="fa fa-trash"></i> Remove</a>
                                                    
                                                  </div>


                                              </form>
                                              </div>

                                              </div>

                                          <!-- PRODUCT -->

                                            <?php
                                          }

                                      }
                                  ?>

        </div>

    </div>
    </form>

</div>