<?php

$start_time = microtime(true);

// code to be timed goes here
$end_time = microtime(true);
$elapsed_time = $end_time - $start_time;
echo "Elapsed time: $elapsed_time seconds";

?>