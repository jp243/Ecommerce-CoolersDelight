-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 11, 2023 at 06:09 PM
-- Server version: 10.6.12-MariaDB-cll-lve
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coolers_delight`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `prod_id`, `user_id`, `quantity`, `total`, `date`) VALUES
(47, 4, 8, 2, 120, '2023-10-11 08:51:39'),
(48, 5, 8, 1, 12, '2023-10-11 08:51:57'),
(49, 8, 8, 1, 15, '2023-10-11 08:51:59');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(40) NOT NULL,
  `cat_description` varchar(100) DEFAULT NULL,
  `dt_encoded` datetime NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_description`, `dt_encoded`, `user_id`) VALUES
(1, 'COOLERS', 'COOLERS PRODUCTS', '2023-08-23 14:07:09', 8),
(2, 'CUPSLIDS', 'CUPS AND LIDS', '2023-08-23 14:07:09', 8),
(3, 'FRIES', 'FRIES FLAVORING', '2023-08-23 14:08:50', 8),
(4, 'MILKTEA', 'MILK TEA POWDER', '2023-08-23 14:08:50', 8),
(5, 'SHAKES', 'SHAKES POWDER', '2023-08-23 14:09:25', 8);

-- --------------------------------------------------------

--
-- Table structure for table `order_status`
--

CREATE TABLE `order_status` (
  `status_id` int(10) UNSIGNED NOT NULL,
  `status_description` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `order_status`
--

INSERT INTO `order_status` (`status_id`, `status_description`) VALUES
(1, 'NEW ORDER'),
(2, 'APPROVED'),
(3, 'DISAPPROVED'),
(4, 'ITEM CHECKING'),
(5, 'PREPARING'),
(6, 'FOR DELIVERY'),
(7, 'LOADED'),
(8, 'EN ROUTE'),
(9, 'DELIVERED'),
(10, 'UNPAID');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `ornumber` varchar(30) NOT NULL,
  `dt_uploaded` timestamp NOT NULL DEFAULT current_timestamp(),
  `receipt_path` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `prod_id` int(11) NOT NULL,
  `prod_name` text NOT NULL,
  `prod_sprice` double NOT NULL,
  `prod_stock` int(11) NOT NULL,
  `prod_img` varchar(255) NOT NULL,
  `date_updated` date NOT NULL,
  `cat_id` int(11) NOT NULL,
  `prod_pprice` double NOT NULL,
  `supplierid` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`prod_id`, `prod_name`, `prod_sprice`, `prod_stock`, `prod_img`, `date_updated`, `cat_id`, `prod_pprice`, `supplierid`) VALUES
(1, 'Float', 40, 10, '364402716_597465928959433_6407465885252867978_n.jpg', '2023-08-20', 1, 0, 0),
(2, 'Mango float', 30, 10, '359540138_1342027346666168_5150493239195825025_n.jpg', '2023-08-20', 2, 0, 0),
(4, 'halo-halo', 60, 10, '358750504_850049600171929_9150505633783921397_n.jpg', '2023-08-20', 3, 0, 0),
(5, 'Mixed', 12, 10, '5.jpg', '2023-08-20', 4, 0, 0),
(7, 'Sample', 15, 8, '6.png', '2023-08-20', 5, 0, 0),
(8, 'Ingredient1', 15, 10, '7.jpg', '2023-08-20', 1, 0, 0),
(9, 'Ingredient2', 15, 10, '9.jpg', '2023-08-20', 1, 0, 0),
(12, 'All Purpose Cream 250g', 62, 50, 'cp_apc250g.jpg', '2023-10-11', 1, 40, 0),
(13, 'ALL PURPOSE CREAM 250G', 62, 50, 'cp_apc250g.jpg', '2023-10-11', 1, 40, 0),
(14, 'ALL PURPOSE CREAM 250G', 62, 50, 'cp_apc250g.jpg', '2023-10-11', 1, 40, 0),
(15, 'All Purpose Cream 250g', 62, 50, 'cp_apc250g.jpg', '2023-10-11', 1, 40, 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `purchaseid` int(10) UNSIGNED NOT NULL,
  `purchase_orderno` varchar(45) NOT NULL,
  `datepurchase` date NOT NULL,
  `ttlamount` double NOT NULL DEFAULT 0,
  `supplier_id` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL,
  `ornumber` varchar(30) NOT NULL,
  `total_sales` double NOT NULL,
  `dt_recorded` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_id` int(11) NOT NULL,
  `status_id` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_id`, `ornumber`, `total_sales`, `dt_recorded`, `user_id`, `status_id`) VALUES
(1, '20231011144918', 90, '2023-10-11 06:54:15', 8, 2);

-- --------------------------------------------------------

--
-- Table structure for table `sales_items`
--

CREATE TABLE `sales_items` (
  `id` int(11) NOT NULL,
  `ornumber` varchar(30) DEFAULT NULL,
  `prod_id` int(11) NOT NULL,
  `sales_qty` tinyint(4) NOT NULL,
  `total` double(15,2) NOT NULL,
  `dt_recorded` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_id` int(11) NOT NULL,
  `remarks` varchar(45) NOT NULL COMMENT '''bad/replaced''',
  `returncode` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_items`
--

INSERT INTO `sales_items` (`id`, `ornumber`, `prod_id`, `sales_qty`, `total`, `dt_recorded`, `user_id`, `remarks`, `returncode`) VALUES
(1, '20231011144918', 8, 1, 15.00, '2023-10-11 06:49:00', 8, '', 0),
(2, '20231011144918', 7, 1, 15.00, '2023-10-11 06:49:00', 8, '', 0),
(3, '20231011144918', 4, 1, 60.00, '2023-10-11 06:49:00', 8, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supplierid` int(10) UNSIGNED NOT NULL,
  `supp_name` varchar(45) NOT NULL,
  `supp_address` varchar(45) NOT NULL,
  `supp_contactno` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplierid`, `supp_name`, `supp_address`, `supp_contactno`) VALUES
(1, 'NESTLE PHILS.', 'SAMPLE ADDRESS', '09991234567'),
(2, 'SAMPLE ONLY', 'SAMPLE ADDRESS', '0998123467');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `firstname` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `middlename` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `lastname` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `officename` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'accounting; commissary',
  `accessrights` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `areano` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `username`, `email`, `password`, `firstname`, `middlename`, `lastname`, `officename`, `accessrights`, `areano`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin123', '', '', '', '', '', 0),
(2, 'finance', 'finance@gmail.com', '1234', 'fin', 'anc', 'finance', 'finance', '2', 1),
(3, 'commisary', 'commisary@gmail.com', '1234', 'com', 'misa', 'comisary', 'commisary', '3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `firstname` text DEFAULT NULL,
  `lastname` text DEFAULT NULL,
  `contact` text DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `contact`, `email`, `password`) VALUES
(2, 'dan villarino', ' villarino', '09382220301', 'zethvillz0501@gmail.com', '$2y$10$Y..9DMIxcOTetmTQ2kC.6ersklweSAxUvhe59cbqCQFtdJrORCJq2'),
(3, 'dan ', 'villarino', '09382220301', 'zethvillz0501@gmail.com', '$2y$10$aJH8oHobQegcYjdMD3n3tuqwd2GEIZmYkqauKdzHAQJ6O3tuRJD4C'),
(4, 'dan ', 'villarino', '09382220301', 'zethvillz0501@gmail.com', '$2y$10$KPmf6s7Eytd9n/n5v6.97.Sux2UJhgGE2EJUA6OFr/c/kM36pYb9y'),
(5, 'dan ', 'villarino', '09382220301', 'zethvillz0501@gmail.com', '$2y$10$ovdao43lg.Nr230pqcXh/encGW8EDUzjBLNCOYEdV1ymbch6/yT16'),
(6, 'asdfasdf', '2sadfasf342', '01234567890', 'johnalmaras@gmail.com', '$2y$10$Zf0wgUa0RBDMEHCLeQ9cOuLn05GRYI50zymoY63XqJ2CjTkixqlpm'),
(8, 'Jaype', 'Bay', '09471852249', 'jaypebayonon@gmail.com', '$2y$10$Odoo9UKJ6YI7qwSW5XqI7Ok6ww3wf3gsmhHx6hf5pJxI8MbJ/q5Ri'),
(10, 'ssdsd', 'dsds', '45454232323223', 'bawigarogine02@gmail.com', '$2y$10$K/5P3I44vNgg5gblbiY8quUrY.wyTjAf4F70oklxnVDIYB1Tau9R6'),
(11, 'jxjd', 'hdbdhd', '47373747373', 'johnalmaras@gmail.com', '$2y$10$IfqnJdqEca4wJs1o9Q95Yu12R7o.yi8JrRNIux/SzK/plUBB49fHC');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `order_status`
--
ALTER TABLE `order_status`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`prod_id`),
  ADD KEY `fk_categoryid` (`cat_id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`purchaseid`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_id`);

--
-- Indexes for table `sales_items`
--
ALTER TABLE `sales_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplierid`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_status`
--
ALTER TABLE `order_status`
  MODIFY `status_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `purchaseid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sales_items`
--
ALTER TABLE `sales_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplierid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_categoryid` FOREIGN KEY (`cat_id`) REFERENCES `category` (`cat_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
