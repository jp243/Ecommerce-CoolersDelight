<?php 
     use PHPMailer\PHPMailer\PHPMailer;
     use PHPMailer\PHPMailer\Exception;
 
     require './PHPMailer/src/Exception.php';
     require './PHPMailer/src/PHPMailer.php';
     require './PHPMailer/src/SMTP.php';
 
     if (isset($_POST['request_otp'])) {   
        
        $email = $_POST['email'];
        //check if email exist
        $checkEmail = checkExistingEmail($email);
        if ($checkEmail->num_rows > 0){
            $name = "Coolers Delight";
            $email = htmlentities($_POST['email']);
            $subject = "Default Password";
            $password = rand_string(8);
            $message = "Your OTP is: ".$password;
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Port = 465;
            $mail->SMTPSecure = 'ssl';
            $mail->Username = 'authcoolersdelight@gmail.com'; //authcoolersdelight@coolersdelight.com
            $mail->Password = 'flba ogkt ikxa cqdz'; 
            $mail->isHTML(true);
            $mail->setFrom($email, $name);
            $mail->addAddress($email);
            $mail->Subject = ("$name ($subject)");
            $mail->Body = $message;
            $register = updateUserOTP($_POST,$password);
            $mail->send();   
            
        }else {
            ?>
            <script>
                alert('Email doesn\'t exist, please contact your system administrator!');
            </script>
            <?php  
        }
        
            // $name = "Coolers Delight";
            // $email = htmlentities($_POST['email']);
            // $subject = "Default Password";
            // $password = rand_string(8);
            // $message = "Your OTP is: ".$password;
            // $mail = new PHPMailer(true);
            // $mail->isSMTP();
            // $mail->Host = 'smtp.gmail.com';
            // $mail->SMTPAuth = true;
            // $mail->Port = 465;
            // $mail->SMTPSecure = 'ssl';
            // $mail->Username = 'authcoolersdelight@gmail.com'; //authcoolersdelight@coolersdelight.com
            // $mail->Password = 'flba ogkt ikxa cqdz'; 
            // $mail->isHTML(true);
            // $mail->setFrom($email, $name);
            // $mail->addAddress($email);
            // $mail->Subject = ("$name ($subject)");
            // $mail->Body = $message;
            // $register = registerUser($_POST,$password);
            // $mail->send();     
     }

     if (isset($_POST['signup'])) { 
        
            $name = "Coolers Delight";
            $email = htmlentities($_POST['email']);
            $subject = "Default Password";
            $password = rand_string(8);
            $message = "Your OTP is: ".$password;
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Port = 465;
            $mail->SMTPSecure = 'ssl';
            $mail->Username = 'authcoolersdelight@gmail.com'; //authcoolersdelight@coolersdelight.com
            $mail->Password = 'flba ogkt ikxa cqdz'; 
            $mail->isHTML(true);
            $mail->setFrom($email, $name);
            $mail->addAddress($email);
            $mail->Subject = ("$name ($subject)");
            $mail->Body = $message;
            $register = registerUser($_POST,$password);
            $mail->send();     
     }
 
     if (isset($_POST['login'])) {
         login($_POST);
     }
 
     if (isset($_POST['add_to_cart'])) {
         addToCart($_POST);
     }
 
     if (isset($_GET['logout'])) {
         logout();
     }
 
     if (isset($_GET['remove'])) {
         removeProductFromCart($_GET, $_SESSION);
     }
     if (isset($_POST['update'])) {
         updateProdFromCart($_SESSION,$_POST);
     }

     if (isset($_POST['confirm_order'])) {         
        confirmOrder($_POST);
    }

    if (isset($_GET['category'])) {        
        FilterProductsByCategory($_GET);
    }

    if (isset($_POST['btnsearch'])) {   
        
        ProductsByName($_POST);
    }

    if (isset($_POST['start_btn'])) {   
        
        // displaytimer();
    }      
    
?>