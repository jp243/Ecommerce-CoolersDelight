<?php 
    require_once("./includes/header.php");
    require_once("./system_proc.php");
?>
<?php require_once("./pages/navbar.php") ?>
    <!-- Tabs content -->
    <section class="h-100 gradient-form" style="background-color: #eee;">
        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-xl-10">
                    <div class="card rounded-3 text-black">
                        <div class="row g-0">
                            <div class="col-lg-6">
                                <div class="card-body p-md-5 mx-md-4">

                                    <div class="text-center">
                                        <img src="./assets/img/coolers_logo.jpg"
                                            style="width: 185px;" alt="logo">
                                        <h4 class="mt-1 mb-5 pb-1">Coolers Delight Team</h4>
                                    </div>

                                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post">
                                        <p>Please login to your account</p>
                                        <div class="form-outline mb-4">
                                            <input type="text" id="loginName" class="form-control" name="email"
                                            placeholder="Phone number or email address" />
                                            <label class="form-label" for="loginName">Username</label>
                                        </div>

                                        <div class="text-center pt-1 mb-3 pb-1">
                                            <button class="button btn btn-primary btn-block mb-4" name="request_otp" type="submit">Request OTP</button>
                                            <!-- <input type="text" name="otp_time" id="otp_time" value="0"> -->
                                            <p id="timer"></p>
                                        </div>
                                        <!-- <div class="timer">
                                                <span class="hour">00</span>:<span class="minute">00</span>:<span class="second">00</span>
                                        </div> -->
                                        <div class="form-outline mb-4">
                                            <input type="text" id="loginOTP" name="loginOTP" class="form-control" name="password"/>
                                            <label class="form-label" for="loginOTP">OTP</label>
                                        </div>

                                        <div class="form-outline mb-4">
                                            <input type="password" id="loginPassword" class="form-control" name="password"/>
                                            <label class="form-label" for="loginPassword">Password</label>
                                        </div>

                                        <div class="text-center pt-1 mb-5 pb-1">
                                            <button class="button btn btn-primary btn-block mb-4" type="submit" name="login" id="login">Login</button>
                                            <!-- <a class="text-muted" href="#!">Forgot password?</a> -->
                                        </div>
                                        
                                        <script>                                                
                                            // set the date we are counting down to                                            
                                            let time_div = document.getElementById('timer');
                                            var time = 120;
                                            let otp_field = $('#otp_time');
                                            let btn_login = $('#login');
                                            let btn_otp = $('#request_otp');
                                            let time_start_stop = 0;
                                            let timer = function(x) {
                                                
                                                    if(x === 0) {
                                                        time_div.innerHTML = 'OTP expires in: ' + x;
                                                        // otp_field.attr('value', x);
                                                        console.log('timer ' + x);
                                                        btn_login.addClass("disabled");    
                                                        document.getElementById('request_otp').disabled = false;                                                                                        
                                                        return;
                                                    }
                                                    // $('#request_otp').addClass("disabled");
                                                    time_div.innerHTML = 'OTP expires in: ' + x;
                                                    otp_field.attr('value', x);
                                                    return setTimeout(() => {timer(--x)}, 1000)                                                
                                            }   

                                            timer(time);

                                            btn_otp.on('click', function(){
                                                alert('otp clicked function');
                                                btn_login.removeClass('disabled');
                                                timer(time);
                                            });
                                        </script>   
                                        <!-- <div class="d-flex align-items-center justify-content-center pb-4">
                                            <p class="mb-0 me-2">Don't have an account?</p>
                                            <button type="button" class="btn btn-outline-danger">Create new</button>
                                        </div> -->
                                    </form>
                                </div>
                            </div>
                            <div class="col-lg-6 d-flex align-items-center ">
                                    <div class="text-center">
                                        <img src="./assets/img/coolersdelight_store.jpg"
                                            style="width: 185px;" alt="logo">                                        
                                            <div class="text-dark px-3 py-4 p-md-5 mx-md-4">
                                                <h4 class="mb-4">We are more than just a company</h4>
                                                <p class="small mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                                                exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                            </div>
                                    </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  <!-- Tabs content -->


<?php
require_once("./pages/modals.php");
require_once("./includes/footer.php");
 ?>