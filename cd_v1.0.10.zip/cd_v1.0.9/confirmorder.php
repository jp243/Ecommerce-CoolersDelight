<?php
    require_once('includes/config.php');
    $action = htmlentities($_POST['confirm']);
    $user = htmlentities($_POST['user']);
    if(isset($action)){
        confirmOrder($user);
        echo "inside confirm order";         
    }

    function confirmOrder($data){

        $user_id = $data;
        $date = date('Y-m-d H:i:s');
        $ornum = preg_replace('/[^0-9]/', '', $date);
        
        insertSales($data, $ornum);
        insertSalesItems($data, $ornum);
        deleteCartItems($user_id);
        
        echo 'Order successfull!';

        // <!-- <script>
        //     alert("Order successfull!")
        //     window.location.href = "index.php#menu"
        // </script>
        
    
    }
    
    function insertSales($data, $or){
        date_default_timezone_set('Asia/Manila');
        $user_id = $data;;
    
        // Then call the date functions
        $date = date('Y-m-d H:i:s');
        // conn()->query("INSERT INTO sales SET ornumber = $or, dt_recorded=$date, user_id='$user_id',status=0");
        $insertItemSql ="INSERT INTO sales SET ornumber = $or, dt_recorded=$date, user_id='$user_id',status=0";
                // $insertItemSql = 'INSERT INTO item(itemNumber, itemName, discount, stock, unitPrice, status, description) VALUES(:itemNumber, :itemName, :discount, :stock, :unitPrice, :status, :description)';
				$insertItemStatement = conn()->prepare($insertItemSql);
				$insertItemStatement->execute();
				echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Item added to database.</div>';
				
    }
    
    function insertSalesItems($data, $salesId){
    
        $user_id = $data;;
        // conn()->query("INSERT INTO sales_items(prod_id, sales_qty, total) SELECT prod_id, quantity, total FROM cart WHERE user_id =$user_id");
        $insertItemSql = "INSERT INTO sales_items(prod_id, sales_qty, total) SELECT prod_id, quantity, total FROM cart WHERE user_id =$user_id";
        $insertItemStatement = conn()->prepare($insertItemSql);
        $insertItemStatement->execute();
        echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Item added to database.</div>';
        updateSalesItems($salesId,$user_id);
        exit();
        
    }
    
    function updateSalesItems($salesId,$user){
        $date = date('Y-m-d H:i:s');
        $insertItemSql = "UPDATE sales_items SET ornumber=$salesId, dt_recorded=$date, user_id=$user";

        $insertItemStatement = conn()->prepare($insertItemSql);
        $insertItemStatement->execute();
        echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">&times;</button>Item added to database.</div>';
   
    }
    

?>