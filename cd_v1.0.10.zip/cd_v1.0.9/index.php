<?php 
    require_once("./includes/header.php");
    require_once("./system_proc.php");
?>
<?php require_once("./pages/navbar.php") ?>
<?php 
    if(!isset($_SESSION['user_id'])){
		header('Location: login.php');
		exit();
	}
?>
    <!-- Tabs content -->
<div class="tab-content" id="ex1-content">
    <div class="tab-pane fade" id="home" role="tabpanel" aria-labelledby="ex1-tab-1">

        <div class="container">

    
            <div class="row">
        
                <div class="col-lg-6 d-flex justify-content-center align-items-center"  style="height: calc(100vh - 100px);">
        
                  <div class="w-100">
                    <div class=" bg-light p-2 mb-4 border-end border-1" id="banner">
                        <h5 class="mb-0">Welcome to Coolers Delight</h5>
                    </div>
        
                    <h1 class="mb-3">
                        KINGS OF QUALITY FOOD
                    </h1>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio quo earum eveniet, autem aspernatur nostrum commodi quae deleniti? Laudantium, recusandae?</p>
                    <a class="btn rounded-pill border border-light text-light shadow-0" id="link-order">Order Now</a>
                  </div>
        
                </div>
        
        
                <div class="col-lg-6 d-flex justify-content-center align-items-center" style="height: calc(100vh - 100px);">
                    
                    <div class="rounded-circle" style="height: 300px; width:300px; background:url(./assets/img/277672662_352067610270815_2211142084973792741_n.jpg); background-size: cover; background-position: center;">
         
                    </div>
        
                </div>
        
        
            </div>
        
          </div>

    </div>
    <!-- MENU -->
    <div class="tab-pane mt-lg-5 active show" id="menu" >
        
        <div class="container-fluid px-lg-5">
            <div class="row">
                <div class="col-lg-3" style="height: fit-content;">
                    <form action="" method="GET">
                        <div class="d-flex">
                            <input type="search" id="searchTxt" name="search" class="form-control" placeholder="Search..">
                            <button type="button" onclick="getInputValue();" class="btn" id ="search_btn"name="btnsearch" class="form-control w-25 ms-1"><i class="fa fa-search"></i></a>
                            <script>
                                function getInputValue(){
                                        // Selecting the input element and get its value 
                                        var inputVal = document.getElementById('searchTxt').value;                                        
                                        // Displaying the value
                                        window.location = "?name=" + inputVal;
                                    }
                            </script>
                        </div>
                    </form>

                        <div class="mt-3 mb-lg-0 mb-3">
                            <h5 class="text-light ">Categories</h5>
                            <ul class="nav flex-column" id="categories">
                                <li class="nav-item position-relative">
                                    <a href="index.php" id="coolers_all" class="nav-link text-light">All</a>
                                    <i class="fa fa-arrow-right position-absolute end-0 top-0 mt-3 text-light"></i>
                                </li>
                                <li class="nav-item">
                                    <a href="?id=1" class="nav-link text-light">Coolers Products</a>
                                </li>
                                <li class="nav-item">
                                    <a href="?id=2" class="nav-link text-light">Cups and Lids</a>
                                </li>
                                <li class="nav-item">
                                    <a href="?id=3"  class="nav-link text-light">Fries Flavoring</a>
                                </li>                                
                                <li class="nav-item">
                                    <a href="?id=4"  class="nav-link text-light">Milk Tea Powder Products</a>
                                </li>                                
                                <li class="nav-item">
                                    <a href="?id=5"  class="nav-link text-light">Shakes Powder</a>
                                </li>                                
                            </ul>                 
                        </div>
                </div>
              <!-- MENU -->
              <?php 
				
				require_once("./pages/menu.php") 
				
				?>
              <!-- MENU -->

            </div>

        </div>


    </div>
    <!-- MENU -->

    <!-- ORDER TRACKING -->
    <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="ex1-tab-3">
    <div class="container mt-5">
            <div class="d-flex justify-content-center row">
                <div class="col-md-10">
                    <div class="rounded">
                        <div class="table-responsive table-borderless">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th class="text-center">
                                            <div class="toggle-btn">
                                                <div class="inner-circle"></div>
                                            </div>
                                        </th>
                                        <th>Order #</th>
                                        <th>Franchisers</th>
                                        <th>Total</th>
                                        <th>Created</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                        
                                    </tr>
                                </thead>
                                <tbody class="table-body">
                                <?php 
                                      $ord_que = GetUserOrders($_SESSION['user_id']);
                                    //   $ord_que = GetUserOrders($_SESSION['user_id']);
                                      if ($ord_que->num_rows > 0) {
                                          
                                          while ($orders = $ord_que->fetch_array()) {                                          
                                        
                                ?>
                                    <tr class="cell-1">
                                        <td class="text-center">
                                            <div class="toggle-btn">
                                                <div class="inner-circle"><?php echo $orders['sales_id'] ?></div>
                                            </div>
                                        </td>
                                        <td><?php echo $orders['ornumber'] ?></td>
                                        <td><?php echo $orders['lastname'] ?></td>
                                        <td>
                                            <?php
                                                if(getTotalSales($orders['ornumber'])> 0 || !empty(getTotalSales($orders['ornumber']))){
                                                    echo '₱ '.getTotalSales($orders['ornumber']); 
                                                } else{
                                                    echo '₱ 0.00'; 
                                                }
                                            ?>
                                        </td>
                                        <td><?php echo $orders['dt_recorded'] ?></td>
                                        <td>
                                            <span class="badge badge-success">
                                                <?php 
                                                    $stat = $orders['status_id'];
                                                    $remarks = $orders['status_description'];
                                                    switch($stat)
                                                    {
                                                        case "1": echo "Customer...".$remarks;
                                                            break;
                                                        case "2": echo "Finance->".$remarks;
                                                            break;
                                                        case "3": echo "Finance->".$remarks;
                                                            break;
                                                        case "4": echo "Commissary->".$remarks;
                                                            break;
                                                        case "5": echo "Commissary->".$remarks;
                                                            break;
                                                        case "6": echo "Commissary->".$remarks;
                                                            break;
                                                        case "7": echo "Logistics->".$remarks;
                                                            break;
                                                        case "8": echo "Logistics->".$remarks;
                                                            break;
                                                        case "9": echo "Customer->".$remarks;
                                                            break;
                                                        default:
                                                            echo "Unreached";
                                                    }
                                                ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php 
                                            //<input type="file" name="image" required>                                                   
                                                if($orders['status_id']<8 || $orders['status_id']>8){
                                                    echo $remarks;
                                                }else {
                                                    ?>
                                                        <a class="btn btn-primary" 
                                                            onclick='javascript:confirmationUpdate($(this));return false;' 
                                                            href="<?php echo "?update&oid=$orders[sales_id]" ?>" 
                                                            role="button">Receive
                                                        </a>
                                                    <?php
                                                }
                                            ?>
                                        </td>
                                        <!-- <td><i class="fa fa-ellipsis-h text-black-50"></i></td> -->
                                    </tr>  
                                    <?php 
                                        }
                                    }
                                    ?>                                  
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ORDER TRACKING -->

    <!-- ORDER TRACKING -->
    <div class="tab-pane fade" id="track_order" role="tabpanel" aria-labelledby="ex1-tab-4">
        
    </div>
    <!-- ORDER TRACKING -->

     <!-- CART -->
    <?php require_once("./pages/cart.php") ?>
    <!-- CART -->

  </div>
  <!-- Tabs content -->
<script>
 
  function confirmationUpdate(anchor)
    {
        var conf = confirm('Received items in good condition?','Coolers Delight');
        if(conf){
            window.location=anchor.attr("href");
        }
    }


</script>

<?php
     if (isset($_GET['update'])) {
        UpdateStatus();        
     }

require_once("./pages/modals.php");
require_once("./includes/footer.php");
 ?>